# Bank Loan Portfolio Analytics

**Tools:** SQL • Python • Pandas • Power BI • DAX • Excel

## Objective
Analyze loan portfolio performance, borrower risk and funding trends to support business decision-making.

## Key Results
- 38,600+ loan applications analyzed
- $435.8M funded capital assessed
- 13.8% bad-loan exposure identified ($65.5M)
- 128,976 source rows cleaned to 37,514 records
- Key KPIs included DTI, interest rate and MTD/MoM trends
- Debt consolidation identified as a major portfolio risk driver

## Workflow
1. Data quality and null audit
2. Data type validation and cleaning
3. Exploratory analysis using Python/SQL
4. KPI engineering
5. Power BI dashboard development
6. Business findings and recommendations

## Skills Demonstrated
SQL querying, Python data preparation, EDA, KPI design, data quality, Power BI and business storytelling.

> Portfolio note: the repository documents the project as presented in my resume. Source/client data is not included unless it is publicly shareable.
