# Apollo Healthcare Analysis

**Tools:** Power BI • DAX • Excel

## Objective
Build a healthcare business intelligence dashboard covering revenue, insurance, occupancy and physician feedback.

## Key Results
- INR 4,105M+ revenue modeled
- 22–24% insurance shortfall observed across 6 diagnoses
- Bed occupancy tracked across 3 ward types
- Approximately 16,500 physician feedback records tracked
- 8,800+ healthcare records cleaned and validated
- Interactive KPI reporting with drill-downs and date slicers

## Workflow
1. Data cleaning and validation
2. Data modeling
3. KPI definition
4. DAX measures
5. Dashboard design
6. Trend and exception analysis

> Portfolio note: this case study is based on the project described in my resume. No private healthcare data is included.
