# Amazon India Sales Analysis

**Tools:** Python • Pandas • NumPy • Seaborn • Matplotlib

## Objective
Explore e-commerce sales data to understand product, customer and regional performance.

## Key Findings
- M and L sizes were the leading sizes at approximately 36% of units
- Cancellation rate was approximately 14%
- B2C represented approximately 99.3% of sales
- Maharashtra, Karnataka and Tamil Nadu were among the highest-volume regions
- Built 8+ visualizations for product and regional analysis

## Workflow
1. Data inspection
2. Missing-value and quality checks
3. Feature exploration
4. Product and regional analysis
5. Visualization
6. Business insights

> Portfolio note: the repository documents the analysis described in my resume. Dataset files are intentionally omitted unless they are publicly shareable.
