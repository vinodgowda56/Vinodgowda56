# Hi, I'm Vinod M 👋

### Data Analyst | BI & Reporting | SQL • Python • Power BI • Advanced Excel

📍 Dubai, United Arab Emirates  
📧 gowdavinod642@gmail.com  
🔗 LinkedIn: https://www.linkedin.com/in/vinod-m02

I’m a BCA graduate and data professional focused on turning business data into clear, actionable insights. My work covers finance, healthcare and e-commerce analytics, with hands-on experience in SQL, Python, Power BI, Advanced Excel, data cleaning, EDA, KPI reporting and dashboard development.

## 🚀 What I Work With

- **SQL:** MySQL, PostgreSQL
- **Python:** Pandas, NumPy
- **BI & Visualization:** Power BI, DAX, Power Query, Tableau, Matplotlib, Seaborn
- **Excel:** VLOOKUP, Pivot Tables, Macros, KPI reporting
- **Analytics:** EDA, data cleaning & wrangling, statistical analysis, A/B testing, ETL
- **Tools:** Jupyter Notebook, Google Sheets, Git/GitHub, MS Office, Azure

## 📊 Featured Projects

### 1. Bank Loan Portfolio Analytics
Analyzed 38,600+ loan applications and $435.8M in funded capital using SQL, Python and EDA. Built KPI dashboards covering DTI, interest rate and MTD/MoM metrics, identified 13.8% bad-loan exposure ($65.5M), and cleaned 128,976 rows down to 37,514 records.

➡️ [View project](./projects/bank-loan-portfolio-analytics/)

### 2. Amazon India Sales Analysis
Analyzed e-commerce sales to identify product and regional trends. M/L sizes represented about 36% of units, the cancellation rate was 14%, and B2C represented 99.3% of sales. Used Python, Pandas, NumPy, Seaborn and Matplotlib.

➡️ [View project](./projects/amazon-india-sales-analysis/)

### 3. Apollo Healthcare Analysis
Built an end-to-end Power BI dashboard modeling INR 4,105M+ in revenue. Analyzed insurance shortfalls, bed occupancy and physician feedback, including approximately 16,500 feedback records and 8,800+ cleaned healthcare records.

➡️ [View project](./projects/apollo-healthcare-analysis/)

## 💼 Experience

**Data Analysis Intern — Auspify Technologies** | Jun 2026 – Jul 2026  
Financial data reconciliation, Excel analysis, pivot tables, VLOOKUP and KPI reporting.

**Accounts & Data Operations Executive — Cappere Solutions** | Feb 2022 – Jan 2023  
Financial datasets, billing/invoicing, validation and reporting-ready data preparation.

**Accounting Software Expert — Sun Pharmaceuticals** | Jun 2021 – Dec 2021  
Tally and Excel-based financial data management, reconciliation and reporting.

## 🎓 Education

**Bachelor of Computer Applications (BCA)**  
Asian International University, Manipur | 2023–2026 | CGPA: 7.35

## 📜 Certifications & Training

- GenAI Powered Data Analytics — TATA Group
- Data Analyst Job Simulation — Deloitte
- Data Labeling — Forge
- Medical Coding & Billing Training Program — Transorze Information Processing Solutions

## 📄 Resume

[Download my Data / BI / Reporting resume](./resume/VINOD_M_Data_BI_Reporting_Resume.pdf)

## 🎯 Current Focus

Data Analyst • BI Analyst • Reporting Analyst • MIS / Reporting • Data Operations

---

⭐ Thanks for visiting my portfolio!
